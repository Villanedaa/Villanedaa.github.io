// CONFIGURACIÓN DE FIREBASE
// Pegue aquí los 4 datos de su proyecto (Firebase → Configuración del proyecto → Tus apps → "Configuración del SDK").
const FIREBASE_CONFIG = {
  apiKey: "",
  authDomain: "",
  projectId: "",
  appId: ""
};

// Minutos de inactividad antes de cerrar la sesión automáticamente.
const SESION_MIN = 30;

// Déjelo en false para EXIGIR inicio de sesión (recomendado).
// Ponga true solo para probar sin Firebase: los datos quedan solo en ese navegador y sin contraseña.
const MODO_LOCAL = false;
